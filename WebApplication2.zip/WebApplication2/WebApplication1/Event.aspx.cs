﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class Form : System.Web.UI.Page
    {
        BLLClass bl = new BLLClass();
        string mailid;      
      
        protected void Page_Load(object sender, EventArgs e)
        {          
            mailid = Request.QueryString["mail"];
            lblmailid.Text = mailid;
            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection("Data source = PC430739; database=clg; uid=sa; password=password-1");                
                ddleventtype.DataTextField = "eventtype";
                ddleventtype.DataValueField = "Id";
                SqlCommand cmd = new SqlCommand("Select * from eventtype", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                ddleventtype.DataSource = dt;
                ddleventtype.DataBind();                
            }
        }    

       

        protected void ddleventtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddleventname.Items.Clear();
            ddleventname.Items.Add("Select event");
            SqlConnection con = new SqlConnection("Data source = PC430739; database=clg; uid=sa; password=password-1");
            ddleventname.DataTextField = "eventname";
            ddleventname.DataValueField = "id";
            SqlCommand cmd = new SqlCommand("Select * from eventname where typeid=" + ddleventtype.SelectedItem.Value, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            ddleventname.DataSource = dt;
            ddleventname.DataBind();
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            int r = bl.events(txtname.Text, mailid, RBGender.Text, long.Parse(txtphone.Text), txtclgname.Text, ddldept.Text, ddlcity.Text, ddleventname.Text);

            if (r == 1)
            {
                lblerror1.Text = "Registered Successfully";
            }
            else
            {
                lblerror1.Text = "Error Occured";
            }
        }
    }
}
