﻿using System;
using BLL;

namespace WebApplication1
{
    public partial class LoginPage : System.Web.UI.Page
    {
        BLLClass bl = new BLLClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            //Session["id"] = txtmailid2.Text;
        }

        protected void btn2_Click(object sender, EventArgs e)
        {
            int q = bl.login(txtmailid2.Text, txtpassword2.Text);
            if(q==1)
            {             
              Response.Redirect("Event.aspx?mail=" + txtmailid2.Text);
            }            
        }
    }
}
