﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class BLLClass
    {
        DALclass da = new DALclass();
        public int registerBLL(string name, string mailid, string password)
        {
            return da.registerDAL(name, mailid, password);
        }
        public int login(string mailid, string password)
        {
            return da.login(mailid, password);
        }
        //public string setmailid(string mail)
        //{
        //    return da.setmailid(mail);
        //}

        public int events(string name,string mailid, string gender, long phone, string clg, string dept, string city, string eventname)
        {
            return da.events(name,mailid,gender, phone, clg, dept, city, eventname);
        }
        
    }
}
