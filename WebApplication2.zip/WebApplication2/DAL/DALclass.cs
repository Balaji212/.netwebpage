﻿
using System.Data;
using System.Data.SqlClient;


namespace DAL
{
    public class DALclass
    {
        public int registerDAL(string name, string mailid, string password)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=clg; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "register";
            cmd.Parameters.Add("@name", name);
            cmd.Parameters.Add("@mailid", mailid);
            cmd.Parameters.Add("@password", password);
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if(r==1)
            {
                return r;
            }
            else
            { return r;  }
        }
        public int login(string mailid,string password)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=clg; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "logins";
            cmd.Parameters.AddWithValue("@mailid", mailid);
            cmd.Parameters.AddWithValue("@password", password);
            int r = (int)cmd.ExecuteScalar();
            con.Close();           
            return r;
        }
       
        public int events(string name,string mailid,string gender,long phone,string clg,string dept,string city,string eventname)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=clg; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "eventdetail";
            cmd.Parameters.Add("@name2", name);
            cmd.Parameters.Add("@mailid2", mailid);
            cmd.Parameters.Add("@gender",gender);
            cmd.Parameters.Add("@phone", phone);
            cmd.Parameters.Add("@clgname", clg);
            cmd.Parameters.Add("@dept", dept);
            cmd.Parameters.Add("@city", city);
            cmd.Parameters.Add("@eventname", eventname);
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r == 1)
            {
                return r;
            }
            else
            { return r; }
        }
    }
}
